package assignment21;

import java.util.Random;
import java.util.Scanner;

public class Assignment21 {

    public static void main(String[] args) {

        int number = 0;
        int num;
        int i = 0;
        int guess = 0;

        Scanner keyboard = new Scanner(System.in);
        Random randomobj = new Random();
        num = randomobj.nextInt(10);

        System.out.println("****************************");
        System.out.println("Welcome to the Guessing Game");
        System.out.print("****************************");
        System.out.println(" ");

        while (number != num) {
            System.out.print("Enter a number from 1 to 10 : ");

            number = keyboard.nextInt();
            guess++;

            if (number == num) {
                System.out.println("You won! the number was " + number);
            } else {
                System.out.println("Try Again...");
            }
        }
        System.out.println("It took you " + guess + " guesses to win");
    }

}
